﻿using AutoMapper;
using DATOS;

namespace Examen2WilberthMolina.App_Start
{
    public static class AutoMapperWebConfiguration
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
            {
               /* acá van unos mapeos */

            });
        }
    }
   
}